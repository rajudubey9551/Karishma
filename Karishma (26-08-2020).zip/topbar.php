<div class="header-top-bar-container clearfix">
				<div class="header-top-bar">
					<ul class="contact-details clearfix">
						<li class="template-phone href">
							<a href="tel:+919818896969">+91-9818 896 969</a>
						</li>
						<li class="template-mail href">
							<a href="mailto:info@karishmatiles.com">Info@karishmatiles.com</a>
						</li>
						<li class="template-location href">
							<a href="contact-us">Find A Showroom Near You</a>
							
						</li>
					</ul>
					<!-- <div class="search-container">
						<a class="template-search" href="#" title="Search"></a>
						<form class="search">
							<input type="text" name="s" placeholder="Search..." value="Search..." class="search-input hint">
							<fieldset class="search-submit-container">
								<span class="template-search"></span>
								<input type="submit" class="search-submit" value="">
							</fieldset>
							<input type="hidden" name="page" value="search">
						</form>
					</div> -->
					<ul class="social-icons">
						<li>
							<a target="_blank" href="https://www.facebook.com/karishmatilesindia/" class="social-facebook" title="facebook"></a>
						</li>
						<li>
							<a target="_blank" href="https://www.instagram.com/karishmatiles_/" class="social-instagram" title="Instagram"></a>
						</li>
						<!-- <li>
							<a target="_blank" href="https://twitter.com/QuanticaLabs" class="social-twitter" title="twitter"></a>
						</li>
						<li>
							<a href="https://pinterest.com/quanticalabs/" class="social-pinterest" title="pinterest"></a>
						</li> -->
						
					</ul>
				</div>
				<a href="#" class="header-toggle template-arrow-up"></a>
			</div>